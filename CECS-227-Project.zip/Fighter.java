public interface Fighter{
  public static final String FIGHTER_MENU = "1. Sword\n2. Axe";
  public static final int NUM_FIGHTER_MENU_ITEMS = 2; 
  public String sword(Entity e);
  public String axe(Entity e);
}